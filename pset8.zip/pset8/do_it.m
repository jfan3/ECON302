% DO_IT.M performs all the calculations and calls output-
% creating routines.  It assumes, that all required variables have been set
solve;
sol_out;
impresp;
moments;
mom_out;
